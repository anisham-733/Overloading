﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloading
{
    interface NumbersAdd
    {
        void add1(int a, int b);
    }
    interface StringAdd
    {
        void add1(string a, string b);
    }
    class Test : NumbersAdd,StringAdd
    {
        public void add1(int a,int b)
        {
            Console.WriteLine(a + b);
        }
        public void add1(string a , string b)
        {
            Console.WriteLine (a + b);
        }

    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Test t = new Test();
            t.add1(10, 20);
            t.add1("hi", " there");
        }
    }
}
